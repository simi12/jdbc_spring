package com.edbconnect.domain;

public class Doctor {
	private int docId;
	private String docName;
	private String docDepartment;
	
	
	
	public Doctor() {
		super();
	}
	public Doctor(int docId, String docName, String docDepartment) {
		super();
		this.docId = docId;
		this.docName = docName;
		this.docDepartment = docDepartment;
	}
	public int getdocId() {
		return docId;
	}
	public void setdocId(int docId) {
		this.docId = docId;
	}
	public String getdocName() {
		return docName;
	}
	public void setdocName(String docName) {
		this.docName = docName;
	}
	public String getdocDepartment() {
		return docDepartment;
	}
	public void setdocDepartment(String docDepartment) {
		this.docDepartment = docDepartment;
	}
	@Override
	public String toString() {
		return "Doctor [docId=" + docId + ", docName=" + docName
				+ ", docDepartment=" + docDepartment + "]";
	}
}
