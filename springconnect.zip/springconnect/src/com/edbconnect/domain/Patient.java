package com.edbconnect.domain;


public class Patient {
	private int ptnId;
	private String ptnName;
	private String ptnDepartment;
	
	
	
	public Patient() {
		super();
	}
	public Patient(int ptnId, String ptnName, String ptnDepartment) {
		super();
		this.ptnId = ptnId;
		this.ptnName = ptnName;
		this.ptnDepartment = ptnDepartment;
	}
	public int getptnId() {
		return ptnId;
	}
	public void setptnId(int ptnId) {
		this.ptnId = ptnId;
	}
	public String getptnName() {
		return ptnName;
	}
	public void setptnName(String ptnName) {
		this.ptnName = ptnName;
	}
	public String getptnDepartment() {
		return ptnDepartment;
	}
	public void setptnDepartment(String ptnDepartment) {
		this.ptnDepartment = ptnDepartment;
	}
	@Override
	public String toString() {
		return "Patient [ptnId=" + ptnId + ", ptnName=" + ptnName
				+ ", ptnDepartment=" + ptnDepartment + "]";
	}
}
