package com.edbconnect.domain;

public class CareTaker {
	private int ctId;
	private String ctName;
	private String ctDepartment;
	
	
	
	public CareTaker() {
		super();
	}
	public CareTaker(int ctId, String ctName, String ctDepartment) {
		super();
		this.ctId = ctId;
		this.ctName = ctName;
		this.ctDepartment = ctDepartment;
	}
	public int getctId() {
		return ctId;
	}
	public void setctId(int ctId) {
		this.ctId = ctId;
	}
	public String getctName() {
		return ctName;
	}
	public void setctName(String ctName) {
		this.ctName = ctName;
	}
	public String getctDepartment() {
		return ctDepartment;
	}
	public void setctDepartment(String ctDepartment) {
		this.ctDepartment = ctDepartment;
	}
	@Override
	public String toString() {
		return "CareTaker [ctId=" + ctId + ", ctName=" + ctName
				+ ", ctDepartment=" + ctDepartment + "]";
	}
}
