package com.edbconnect.client;

import java.util.List;
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.edbconnect.domain.Doctor;
import com.edbconnect.service.DoctorService;

	public class ClientLogic {

		public static void main(String arg[]) {
			
	        ApplicationContext ctx = new ClassPathXmlApplicationContext("config.xml");
	       
	        DoctorService DoctorService = (DoctorService) ctx.getBean("DoctorService");
	        Doctor doc1 = new Doctor(1000, "Bob", "ENT");
	        Doctor doc2 = new Doctor(1001, "Susan", "Pediatric");
	        
	        DoctorService.insertDoctor(doc1);
	        DoctorService.insertDoctor(doc2);
	        
	        System.out.println("Records are successfully added..");       
	        
	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter the docId to be deleted ");
	       
	        int docId = sc.nextInt();
	        int result = DoctorService.removeDoctor(docId);
	        if (result > 0) {
	            System.out.println(" Record Deleted ");
	        } else {
	            System.out.println(" No record found for the given docId ");
	        }              
	}
}
