package com.edbconnect.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.edbconnect.domain.Patient;

	/* value attribute is used to give explicit bean name/id, this name overrides the default bean?
	(which is same as class name lowering first letter) provided by Spring */
	@Repository(value = "PatientDao")
	public class PatientDAOImpl implements PatientDAO {
		
	    private JdbcTemplate jdbcTemplate;
	    
	    @Autowired
	    public void setJdbcTemplate(DataSource dataSource) {
	        this.jdbcTemplate = new JdbcTemplate(dataSource);
	    }
	    public void insert(Patient ptn) {
	        String query = "INSERT INTO Patient(ptnId, ptnName, department) Values (?,?,?)";
	        jdbcTemplate.update(query,new Object[] { ptn.getptnId(), ptn.getptnName(),ptn.getptnDepartment() });
	    }   
	    public int delete(int ptnid) {
	        return jdbcTemplate.update("delete from Patient where ptnid = ? ",ptnid);
	    }
	}
	 

