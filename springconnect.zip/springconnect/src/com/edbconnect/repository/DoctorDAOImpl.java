package com.edbconnect.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.edbconnect.domain.Doctor;

	/* value attribute is used to give explicit bean name/id, this name overrides the default bean?
	(which is same as class name lowering first letter) provided by Spring */
	@Repository(value = "DoctorDao")
	public class DoctorDAOImpl implements DoctorDAO {
		
	    private JdbcTemplate jdbcTemplate;
	    
	    @Autowired
	    public void setJdbcTemplate(DataSource dataSource) {
	        this.jdbcTemplate = new JdbcTemplate(dataSource);
	    }
	    public void insert(Doctor doc) {
	        String query = "INSERT INTO Doctor(docId, docName, department) Values (?,?,?)";
	        jdbcTemplate.update(query,new Object[] { doc.getdocId(), doc.getdocName(),doc.getdocDepartment() });
	    }   
	    public int delete(int docid) {
	        return jdbcTemplate.update("delete from Doctor where docid = ? ",docid);
	    }
	}
	 

