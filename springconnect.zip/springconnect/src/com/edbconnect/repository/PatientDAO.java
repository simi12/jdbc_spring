package com.edbconnect.repository;

import java.util.List;
import com.edbconnect.domain.Patient;
	
	public interface PatientDAO {
	    //Method to insert Patient record
	    public void insert(Patient ptn);
	    //Method to remove a record from Patient table
	    public int delete(int ptnId);
	}

