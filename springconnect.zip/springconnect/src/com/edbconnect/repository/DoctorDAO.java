package com.edbconnect.repository;

import java.util.List;
import com.edbconnect.domain.Doctor;
	
	public interface DoctorDAO {
	    //Method to insert Doctor record
	    public void insert(Doctor doc);
	    //Method to remove a record from Doctor table
	    public int delete(int docId);
	}

