package com.edbconnect.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.edbconnect.domain.CareTaker;

	/* value attribute is used to give explicit bean name/id, this name overrides the default bean?
	(which is same as class name lowering first letter) provided by Spring */
	@Repository(value = "CareTakerDao")
	public class CareTakerDAOImpl implements CareTakerDAO {
		
	    private JdbcTemplate jdbcTemplate;
	    
	    @Autowired
	    public void setJdbcTemplate(DataSource dataSource) {
	        this.jdbcTemplate = new JdbcTemplate(dataSource);
	    }
	    public void insert(CareTaker ct) {
	        String query = "INSERT INTO CareTaker(ctId, ctName, department) Values (?,?,?)";
	        jdbcTemplate.update(query,new Object[] { ct.getctId(), ct.getctName(),ct.getctDepartment() });
	    }   
	    public int delete(int ctid) {
	        return jdbcTemplate.update("delete from CareTaker where ctid = ? ",ctid);
	    }
	}
	 

