package com.edbconnect.repository;

import java.util.List;
import com.edbconnect.domain.CareTaker;
	
	public interface CareTakerDAO {
	    //Method to insert CareTaker record
	    public void insert(CareTaker doc);
	    //Method to remove a record from CareTaker table
	    public int delete(int docId);
	}
