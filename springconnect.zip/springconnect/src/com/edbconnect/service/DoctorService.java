package com.edbconnect.service;

import java.util.List;
import com.edbconnect.domain.Doctor;

public interface DoctorService {
       public void insertDoctor(Doctor doc);
       public int removeDoctor(int docId);      
 }