package com.edbconnect.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.edbconnect.domain.Doctor;
import com.edbconnect.repository.DoctorDAO;

@Service("DoctorService")
public class DoctorServiceImpl implements DoctorService {
    DoctorDAO DoctorDao ;
    public DoctorDAO getDoctorDao() {
        return DoctorDao;
    }
    @Autowired
    public void setDoctorDao(DoctorDAO DoctorDao) {
        this.DoctorDao = DoctorDao;
    }
    public void insertDoctor(Doctor doc) {
        DoctorDao.insert(doc);
    }
    public int removeDoctor(int docId) {
        return DoctorDao.delete(docId);
    }   
}
 